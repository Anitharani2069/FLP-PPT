import { Component, OnInit } from '@angular/core';
import { CustomerService } from '../customer.service';

@Component({
  selector: 'app-category-discount',
  
  templateUrl: './category-discount.component.html',
  styleUrls: ['./category-discount.component.css']
})
export class CategoryDiscountComponent implements OnInit {

 
  

  constructor(private service: CustomerService) { 
  }

  ngOnInit() {
  }

generate(data:any){

  if(data.discount<=0)
  {
    alert("Discount cant be less than 0");
    return null;
  }
  
  if(data.delay<0)
  {
    alert("Delay cant be negative");
    return null;
  }
  
  this.service.discountByCategory(data.category,data.discount,data.delay).subscribe((data)=>{console.log(data);})

}

}
