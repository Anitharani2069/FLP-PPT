import { Component, OnInit } from '@angular/core';
import { CustomerService } from '../customer.service';

@Component({
  selector: 'app-product-discount',
  templateUrl: './product-discount.component.html',
  styleUrls: ['./product-discount.component.css']
})
export class ProductDiscountComponent implements OnInit {

  constructor(private service: CustomerService) { }

  ngOnInit() {
  }

  generate(data:any){

    if(data.discount<=0)
    {
      alert("Discount cant be less than 0");
      return null;
    }
    if(data.pId<0)
    {
      alert("product Id cant be negative");
      return null;
    }
    if(data.delay<0)
    {
      alert("Delay cant be negative");
      return null;
    }

    this.service.discountByProduct(data.pId,data.discount,data.delay).subscribe((data)=>{console.log(data);})
  }

}
