import { Component, OnInit } from '@angular/core';
import { Product } from '../product';
import { CustomerService } from '../customer.service';

@Component({
  selector: 'app-productupdate',
  templateUrl: './productupdate.component.html',
  styleUrls: ['./productupdate.component.css']
})
export class ProductupdateComponent implements OnInit {

  product=new Product();
  constructor(private service:CustomerService) { }

  ngOnInit() {
   this.product=this.service.getProductTemp();
   //alert(this.product.productId);
  }
  updateProduct(data)
  {
    this.service.updateProduct(data,data.productId).subscribe(data=>console.log(data));
    alert("Product Updated Successfully");
  }


}
