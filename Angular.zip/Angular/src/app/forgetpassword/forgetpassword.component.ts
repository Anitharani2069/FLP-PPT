import { Component, OnInit } from '@angular/core';
import { Password } from '../password';
import { CustomerService } from '../customer.service';

@Component({
  selector: 'app-forgetpassword',
  templateUrl: './forgetpassword.component.html',
  styleUrls: ['./forgetpassword.component.css']
})
export class ForgetpasswordComponent implements OnInit {

  //email:String;
  //password:string;
  //Password:string;
  ts:Password=new Password();
  
  // ts:Password;
  // ts:String;
  //ts:Password=null;
  // password:String;
  constructor(private service:CustomerService) { }

  ngOnInit() {
     //this.ts.emailid=this.email;
    //this.ts.password=this.password;
    // this.service.getPassword(this.ts.emailid,this.ts.password).subscribe(data=>{this.ts=data});
  }

  get(data){
    
   
    this.service.getPassword(data.email,data.type).subscribe(value1=>this.ts.merchantPassword=value1);
    //this.service.getPassword(data.email,data.type).subscribe(value1=>this.ts.customerPassword=value1);
    
    
    //this.service.getPassword(data.email,data.type).subscribe(value1=>this.ts.merchantPassword=value1);
   
    //alert(this.ts.password);
  }
  getCustomer(data1)
  {
    this.service.getPassword(data1.email,data1.type).subscribe(value1=>this.ts.customerPassword=value1);
  }
getAdmin(data2)
{
  this.service.getPassword(data2.email,data2.type).subscribe(value1=>this.ts.password=value1);
}

}
