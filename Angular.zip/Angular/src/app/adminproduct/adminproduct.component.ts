import { Component, OnInit } from '@angular/core';
import { CustomerService } from '../customer.service';
import { Product } from '../product';

@Component({
  selector: 'app-adminproduct',
  templateUrl: './adminproduct.component.html',
  styleUrls: ['./adminproduct.component.css']
})
export class AdminproductComponent implements OnInit {

  product: Product[];

  constructor(private httpClientService: CustomerService) { }

  ngOnInit() {
    this.httpClientService.showProducts().subscribe(data => this.product = data);
  }

  deleteProduct(data) {
    alert(data.productId);
    this.httpClientService.deleteProduct(data.productId).subscribe(data=>console.log(data));
  }

}
