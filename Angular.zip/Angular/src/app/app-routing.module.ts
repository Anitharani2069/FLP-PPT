import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import {RouterModule,Routes} from '@angular/router';
import { FirstpageComponent } from './firstpage/firstpage.component';
import { SigninComponent } from './signin/signin.component';
import { AdminsigninComponent } from './adminsignin/adminsignin.component';
import { AdminpageComponent } from './adminpage/adminpage.component';
import { MerchantsigninComponent } from './merchantsignin/merchantsignin.component';
import { MerchantsignupComponent } from './merchantsignup/merchantsignup.component';
import { HomepageComponent } from './homepage/homepage.component';
import { AdmincustomerComponent } from './admincustomer/admincustomer.component';
import { AdminmerchantComponent } from './adminmerchant/adminmerchant.component';
import { AdminproductComponent } from './adminproduct/adminproduct.component';
import { AdminallmerchantComponent } from './adminallmerchant/adminallmerchant.component';
import { DiscountComponent } from './discount/discount.component';
import { CategoryDiscountComponent } from './category-discount/category-discount.component';
import { AmountDsicountComponent } from './amount-dsicount/amount-dsicount.component';
import { ProductDiscountComponent } from './product-discount/product-discount.component';
import { MerchantpageComponent } from './merchantpage/merchantpage.component';
import { AdditemComponent } from './additem/additem.component';
import { MyinventoryComponent } from './myinventory/myinventory.component';
import { ProductupdateComponent } from './productupdate/productupdate.component';
import { ForgetpasswordComponent } from './forgetpassword/forgetpassword.component';



const routes:Routes =[
  { path: '', redirectTo: 'CapStore', pathMatch: 'full' },
  {path:'CapStore',component:FirstpageComponent},
  {path:'signin',component:SigninComponent},
  {path:'adminSignIn',component:AdminsigninComponent},
  {path:'adminPage',component:AdminpageComponent},
  {path:'merchantSignIn',component:MerchantsigninComponent},
  {path:'merchantSignUp',component:MerchantsignupComponent},
  {path:'homePage/:id',component:HomepageComponent},
  {path:'adminCustomer',component:AdmincustomerComponent},
  {path:'adminMerchant',component:AdminmerchantComponent},
  {path:'adminProduct',component:AdminproductComponent},
  {path:'allMerchants',component:AdminallmerchantComponent},

  {path:'discount',component:DiscountComponent},
  {path:'categorydiscount',component:CategoryDiscountComponent},
  {path:'productdiscount',component:ProductDiscountComponent},
  {path:'amountdiscount',component:AmountDsicountComponent},

  {path:'merchantpage',component:MerchantpageComponent},
  {path:'additem',component:AdditemComponent},
  {path:'myinventory',component:MyinventoryComponent},
  {path:'updateitem',component:ProductupdateComponent},

  {path:'forgetPassword',component:ForgetpasswordComponent}
];

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forRoot(routes)
  ],
  exports: [RouterModule]
})
export class AppRoutingModule { }
