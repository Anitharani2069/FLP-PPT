import { Component, OnInit } from '@angular/core';
import { Customer } from '../customer';
import { CustomerService } from '../customer.service';
import { Router } from '../../../node_modules/@angular/router';

@Component({
  selector: 'app-signin',
  templateUrl: './signin.component.html',
  styleUrls: ['./signin.component.css']
})
export class SigninComponent implements OnInit {

  all:Customer[]=[];
  oneCustomer:Customer=new Customer();

  constructor(private service:CustomerService, private router:Router) { }

  ngOnInit() {
    this.allCustomerData();
  }

  allCustomerData(){
    this.service.getAllCustomers().subscribe(data=>this.all=data);
  }

  login(data){
    for(let i=0;this.all.length;i++){
      if(data.customerEmail==this.all[i].customerEmail){
        if(data.customerPassword==this.all[i].customerPassword){
          this.oneCustomer=this.all[i];
          let id=this.oneCustomer.customerId;
          console.log(this.oneCustomer);
          alert("Welcome")
          this.router.navigate(['/homePage',id]);
          break;
        }
        else {
          alert("Invalid Credentials");
          break;
        }
      }
    }
  }






  // searching(data) {
  //   let j=0;
  //   this.itemsrhd =[];
  //   for(let i=0;i<this.itemsrh.length;i++) {
  //     if(data.value.name==this.itemsrh[i].name || data.value.name==this.itemsrh[i].category) {
  //       this.itemsrhd[j]=this.itemsrh[i];
  //       j++;
  //     }
  //   }
  

}
