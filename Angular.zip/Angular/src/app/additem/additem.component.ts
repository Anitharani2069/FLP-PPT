import { Component, OnInit } from '@angular/core';
import { Product } from '../product';
import { CustomerService } from '../customer.service';

@Component({
  selector: 'app-additem',
  templateUrl: './additem.component.html',
  styleUrls: ['./additem.component.css'],
  
})
export class AdditemComponent implements OnInit {
  product:Product=new Product();

  constructor(private service:CustomerService) { }

  ngOnInit() {
  }
  additem(all)
  {

      //const data = JSON.stringify(all.value);

     const data = all  // JSON.parse(all);

     

      //alert(all.value.productBrand);
      //alert(all.value.productName);


    this.product.productBrand=all.value.productBrand;
    this.product.productName=all.value.productName;

    this.product.productCategory=all.value.productCategory;
    this.product.productType=all.value.productType;
    this.product.productPrice=all.value.productPrice;
    this.product.productQuantity=all.value.productQuantity; 
    this.product.merchantId = all.value.merchantId;
    

      //alert(data.productBrand)

    this.service.addProduct(this.product).subscribe(adata=>console.log(adata));
    alert("Product Added Successfully");
  }

}
