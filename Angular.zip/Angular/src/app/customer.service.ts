import { Injectable } from '@angular/core';
import { HttpClient } from '../../node_modules/@angular/common/http';
import { Customer } from './customer';
import { Observable } from '../../node_modules/rxjs';
import { Merchant } from './merchant';
import { Product } from './product';

@Injectable({
  providedIn: 'root'
})
export class CustomerService {

  constructor(private http:HttpClient) { }

  private baseUrl = 'http://localhost:1947'


  //Customer
  getAllCustomers(): Observable<any>{
    return this.http.get(`${this.baseUrl}` + `/allCustomer`);
  }
  getOneCustomer(customerId:number) :Observable<any>{
    return this.http.get(`${this.baseUrl}` + `/allCustomer/`+customerId)
  }

  addCustomer(customer:Customer): Observable<any>{
    return this.http.post(`${this.baseUrl}` + `/create`, customer);
  }


  //Merchant
  getAllMerchant(): Observable<any>{
    return this.http.get(`${this.baseUrl}` + `/allMerchant`);
  }
  addMerchant(merchant){
    return this.http.post<Merchant>(`${this.baseUrl}` + `/signupmerchant`, merchant);
  }
  

  //Lavanya
  showCustomers(): Observable<any> {
    return this.http.get(`${this.baseUrl}` + `/allCustomer`);
  }

  deleteCustomer(id: number): Observable<any> {
    return this.http.delete(`http://localhost:1947/delete/` + id);
  }

  showMerchants(): Observable<any> {
    return this.http.get('http://localhost:1947/merchants');
  }
  deleteMerchant(id: number):Observable<any> {
    return this.http.delete(`http://localhost:1947/deleteMerchant/` + id);
  }


  showProducts(): Observable<any> {
    return this.http.get('http://localhost:1947/products');
  }
  deleteProduct(id: number): Observable<any> {
    return this.http.delete(`http://localhost:1947/deleteProduct/` + id);
  }






  //Shreyash
  discountByCategory(category:string,discount:number,delay:number){
    return this.http.put("http://localhost:1947/product/category/"+category+"/"+discount+"/"+delay,"")
  }

  discountByProduct(pId:number,discount:number,delay:number){
    return this.http.put("http://localhost:1947/product/"+pId+"/"+discount+"/"+delay,"")
  }

  discountByAmount(amount:number,discount:number,delay:number){
    return this.http.put("http://localhost:1947/product/amount/"+amount+"/"+discount+"/"+delay,"")
  }



  //Supriya
  productTemp=new Product();

  

  product:Product=new Product();
  private baseUrl6 = 'http://localhost:1947/product/addProduct';
  private baseUrl1 = 'http://localhost:1947/item/getItemByMerchantId';
  private baseUrl2 = 'http://localhost:1947/product/getAllProduct';
  private baseUrl3 = 'http://localhost:1947/product/updateProduct';
  private baseUrl4 = 'http://localhost:1947/product/removeItem';
  private baseUrl5 = 'http://localhost:1947/item/getItemByMerchantId'






  addProduct(product:Product){
    console.log(product);
    return this.http.post<Product>(this.baseUrl6, product);
    }

     getAllItem(merchantId:number): Observable<any[]> {
      return this.http.get<Product[]>(this.baseUrl1+"/"+merchantId);
    }
    setProductTemp(product){
      this.productTemp=product;
    }

    getProductTemp(){
      return this.productTemp;
    }


    getAllProduct():Observable<any>{
      return this.http.get(this.baseUrl2);
    }
    updateProduct(product:Product,productId:number):Observable<any>{
      //console.log(productId);
     // console.log(product);
      return this.http.put<Product>(this.baseUrl3+"/"+productId,product);
    }

    deleteMerchantProduct(productId:number,merchantId:number)
    {
      return this.http.delete(this.baseUrl4+"/"+productId+"/"+merchantId);
    }

    merchantById(merchantId):Observable<any>{
      return this.http.get(this.baseUrl5+"/"+merchantId);
    }



    //Mounica
    getPassword(emailId:String,type:String):Observable<any>{
    return this.http.get('http://localhost:1947/forgetPassword'+"/"+emailId+"/"+type,{responseType:'text'});
    }



  
  
  
}
