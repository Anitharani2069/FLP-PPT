export class Inventory
{
  inventoryId:number;
 productId:number;
	 productName:String;
 productPrice:number;
	 quantity:number;
}
