import { Component, OnInit } from '@angular/core';
import { CustomerService } from '../customer.service';
import { Merchant } from '../merchant';

@Component({
  selector: 'app-adminallmerchant',
  templateUrl: './adminallmerchant.component.html',
  styleUrls: ['./adminallmerchant.component.css']
})
export class AdminallmerchantComponent implements OnInit {

  merchant: Merchant[]=[];
  constructor(private httpClientService: CustomerService) { }

  ngOnInit() {
    this.httpClientService.showMerchants().subscribe(data => this.merchant = data);
  }

  deleteMerchant(data){
    this.httpClientService.deleteMerchant(data.merchantId).subscribe(data=>console.log(data));
  }

}
