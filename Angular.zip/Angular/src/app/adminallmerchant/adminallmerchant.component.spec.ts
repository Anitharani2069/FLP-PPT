import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminallmerchantComponent } from './adminallmerchant.component';

describe('AdminallmerchantComponent', () => {
  let component: AdminallmerchantComponent;
  let fixture: ComponentFixture<AdminallmerchantComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdminallmerchantComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminallmerchantComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
