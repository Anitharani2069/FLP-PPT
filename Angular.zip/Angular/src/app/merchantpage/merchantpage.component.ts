import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-merchantpage',
  templateUrl: './merchantpage.component.html',
  styleUrls: ['./merchantpage.component.css']
})
export class MerchantpageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
