import { Component, OnInit } from '@angular/core';
import { Product } from '../product';
import { Router } from '@angular/router';
import { CustomerService } from '../customer.service';
import { Inventory } from '../inventory';


@Component({
  selector: 'app-myinventory',
  templateUrl: './myinventory.component.html',
  styleUrls: ['./myinventory.component.css']
})
export class MyinventoryComponent implements OnInit {


  allproduct:Product[];
  product:Product=new Product();
  inventory:Inventory[];
  //merchantId = 0;
  constructor(private router: Router,private service:CustomerService) { }

  ngOnInit() {
    //this.service.getAllItem(this.merchantId).subscribe(data =>this.inventory = data);
    this.service.getAllProduct().subscribe(data=>this.allproduct = data);
  }

  show(data){
    this.service.merchantById(data.merchant).subscribe(data=>this.inventory = data);
  }

  
  updateProduct(item){
    //alert(item.productId);
    for(let i=0;this.allproduct.length;i++){
      if(item.productId==this.allproduct[i].productId){
       // alert(this.allproduct[i].productName);
        this.product.productId=this.allproduct[i].productId;
        this.product.productName=this.allproduct[i].productName;
        this.product.productBrand=this.allproduct[i].productBrand;
        this.product.productCategory=this.allproduct[i].productCategory;
        this.product.productType=this.allproduct[i].productType;
        this.product.productPrice=this.allproduct[i].productPrice;
        this.product.productQuantity=this.allproduct[i].productQuantity;
        this.product.merchantId=this.allproduct[i].merchantId;
        console.log(item);
        this.service.setProductTemp(this.product);
        this.router.navigate(['updateitem']);
        break;
      }
    }

    //alert(item.productId);
    // this.product.productId=item.productId;
    // this.product.productName=item.productName;
    // this.product.productBrand=item.productBrand;
    // this.product.productCategory=item.productCategory;
    // this.product.productType=item.productType;
    // this.product.productPrice=item.productPrice;
    // this.product.productQuantity=item.quantity;
    // console.log(item);
    // this.service.setProductTemp(this.product);
    // this.router.navigate(['updateitem']);
  }
  delete(data) {
    //alert(cust.customerId);
    this.service.deleteMerchantProduct(data.productId,data.merchantId).subscribe(data => console.log(data));
    alert('product has been successfully deleted');
   }

}
