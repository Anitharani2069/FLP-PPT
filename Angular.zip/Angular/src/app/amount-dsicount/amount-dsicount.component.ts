import { Component, OnInit } from '@angular/core';
import { CustomerService } from '../customer.service';

@Component({
  selector: 'app-amount-dsicount',
  templateUrl: './amount-dsicount.component.html',
  styleUrls: ['./amount-dsicount.component.css']
})
export class AmountDsicountComponent implements OnInit {

  constructor(private service: CustomerService) { 
  }

  ngOnInit() {
  }

generate(data:any){

  if(data.discount<=0)
  {
    alert("Discount cant be less than 0");
    return null;
  }
  if(data.amount<0)
  {
    alert("Amount cant be less than 0");
    return null;
  }
  if(data.delay<0)
  {
    alert("Delay cant be negative");
    return null;
  }

  
  this.service.discountByAmount(data.amount,data.discount,data.delay).subscribe((data)=>{console.log(data);})

}

}
