import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AmountDsicountComponent } from './amount-dsicount.component';

describe('AmountDsicountComponent', () => {
  let component: AmountDsicountComponent;
  let fixture: ComponentFixture<AmountDsicountComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AmountDsicountComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AmountDsicountComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
