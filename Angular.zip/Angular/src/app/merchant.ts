export class Merchant
{
    merchantId:number;
    merchantEmail:String;
    merchantName:String;
    merchantAddress:String;
    merchantMobile:String;
    merchantPassword:String;
    merchantType:Merchant;

}