package com.capgemini.capstore.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

//import com.capgemini.capstore.bean.CapgAdmin;
import com.capgemini.capstore.beans.Customer;
import com.capgemini.capstore.beans.Merchant;
import com.capgemini.capstore.dao.CapgCustomerDaoImpl;
import com.capgemini.capstore.dao.CapgMerchantDaoImpl;

@Service
public class PasswordServiceImp implements PasswordService {

	// @Autowired
	// CapgAdminDaoImpl adminDao;

	@Autowired
	CapgMerchantDaoImpl merchantDao;

	@Autowired
	CapgCustomerDaoImpl customerDao;

	// @Override
	// public CapgAdmin addAdminService(CapgAdmin admin) {
	// // TODO Auto-generated method stub
	// return adminDao.addAdminDao(admin);
	//
	// }

	@Override
	public Customer addCustomerService(Customer customer) {
		// TODO Auto-generated method stub
		return customerDao.addCustomerDao(customer);
	}

	@Override
	public Merchant addMerchantService(Merchant merchant) {
		// TODO Auto-generated method stub
		return merchantDao.addMerchantDao(merchant);
	}

	// @Override
	// public List<CapgAdmin> getAllAdminService() {
	// // TODO Auto-generated method stub
	// return adminDao.getAllAdminDao();
	// }
	//
	// @Override
	// public CapgAdmin getAdminService(int adminId) {
	// // TODO Auto-generated method stub
	// return adminDao.getAdminDao(adminId);
	// }

	@Override
	public void addCustomerDao(Customer customer) {
		// TODO Auto-generated method stub
		customerDao.addCustomerDao(customer);

	}

	@Override
	public List<Customer> getAllCustomerDao() {
		// TODO Auto-generated method stub
		return customerDao.getAllCustomerDao();
	}

	@Override
	public Customer getCustomerDao(int customerId) {
		// TODO Auto-generated method stub
		return customerDao.getCustomerDao(customerId);
	}

	@Override
	public void addMerchantDao(Merchant merchant) {
		// TODO Auto-generated method stub
		merchantDao.addMerchantDao(merchant);

	}

	@Override
	public List<Merchant> getAllMerchantDao() {
		// TODO Auto-generated method stub
		return merchantDao.getAllMerchantDao();
	}

	@Override
	public Merchant getMerchantDao(int merchantId) {
		// TODO Auto-generated method stub
		return merchantDao.getMerchantDao(merchantId);
	}

	@Override
	public String getPasswordService(String emailId, String type) {

		String password = null;
		// TODO Auto-generated method stub
		if (type.equalsIgnoreCase("customer")) {
			Customer customer = customerDao.getCustomerByEmailDao(emailId);
			password = customer.getCustomerPassword();
		} else if (type.equalsIgnoreCase("merchant")) {
			Merchant merchant = merchantDao.getMerchantByEmailDao(emailId);
			password = merchant.getMerchantPassword();
		}
		// else {
		// CapgAdmin admin = adminDao.getAdminByEmailDao(emailId);
		// password = admin.getPassword();
		// }

		return password;

	}

}
