package com.capgemini.capstore.service;

import java.util.List;

import com.capgemini.capstore.beans.MerchantInventory;
import com.capgemini.capstore.beans.Product;

public interface CapgProductServiceIntf {

	public List<Product> getAllProductsService();

	public Product getProductService(int productId);

	public Product addProductService(Product product);

	public Product updateProductService(Product product,int productId);
	
	public void deleteProduct(int productId);
	
	 public List<MerchantInventory> getAllItemsService();

	public MerchantInventory getItemService(int itemId);

	
}
