package com.capgemini.capstore.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.capstore.service.DiscountServiceInterface;

@RestController
@CrossOrigin(origins="http://localhost:4200")
public class DiscountController {
	
	
	@Autowired
	DiscountServiceInterface service;
	
	@PutMapping(value="/product/{productId}/{productDiscount}/{delay}")
	public void setDiscount(@PathVariable int productId,@PathVariable double productDiscount,@PathVariable int delay) {
		service.setDiscount(productId, productDiscount,delay);
	}
	
	@PutMapping(value="/product/category/{productCategory}/{productDiscount}/{delay}")
	public void setDiscountByCategory(@PathVariable String productCategory,@PathVariable double productDiscount,@PathVariable int delay) {
		service.setDiscountByCategory(productCategory, productDiscount,delay);
	}
	
	@PutMapping(value="/product/amount/{productPrice}/{productDiscount}/{delay}")
	public void setDiscountByPrice(@PathVariable double productPrice,@PathVariable double productDiscount,@PathVariable int delay) {
		service.setDicountByAmount(productPrice, productDiscount,delay);
	}

}
