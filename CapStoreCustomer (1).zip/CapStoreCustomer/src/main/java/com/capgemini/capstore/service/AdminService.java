package com.capgemini.capstore.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.capstore.beans.Customer;
import com.capgemini.capstore.beans.Merchant;
import com.capgemini.capstore.beans.Product;
import com.capgemini.capstore.dao.ICustomerDao;

@Service
public class AdminService implements AdminServiceInterface {

	@Autowired
	ICustomerDao dao;
	
	
	public void deleteCustomer(int customerId) {
		System.out.println(customerId);
		 dao.deleteCustomer(customerId) ;
	}


	@Override
	public List<Customer> findAllCustomers() {
		return dao.findAllCustomers();
	}


	@Override
	public List<Product> findAllProducts() {
		return dao.findAllProducts();
	}
	


	@Override
	public List<Merchant> findAllMerchants() {
	return dao.findAllMerchants();
	}


	@Override
	public void deleteProduct(int productId) {
		dao.deleteProduct(productId);
	}


	@Override
	public void deleteMerchant(int merchantId) {
		dao.deleteMerchant(merchantId);
	}

}
