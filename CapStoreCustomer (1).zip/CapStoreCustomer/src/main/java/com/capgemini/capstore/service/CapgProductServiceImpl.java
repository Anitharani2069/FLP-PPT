package com.capgemini.capstore.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.capstore.beans.MerchantInventory;
import com.capgemini.capstore.beans.Product;
import com.capgemini.capstore.dao.CapgMerchantInventoryDaoImpl;
import com.capgemini.capstore.dao.CapgProductDaoImpl;

@Service
public class CapgProductServiceImpl implements CapgProductServiceIntf {

	@Autowired
	CapgProductDaoImpl productDao;
	@Autowired
	CapgMerchantInventoryDaoImpl inventoryDao;

	static int count = 1;

	@Override
	public List<Product> getAllProductsService() {
		return productDao.getAllProductsDao();
	}

	@Override
	public Product getProductService(int productId) {
		// TODO Auto-generated method stub
		return productDao.getProductDao(productId);
	}

	@Override
	public Product addProductService(Product product) {
		// TODO Auto-generated method stub

//		   CapgMerchantInventory inventory = new CapgMerchantInventory();
//		 inventory.setInventoryId(count++);
//		  
//		  inventory.setProductName(product.getProductName());
//		  inventory.setProductPrice(product.getProductPrice());
//		  inventory.setQuantity(product.getProductQuantity());
//		  inventoryDao.addItemDao(inventory); 
//		  CapgProduct product_saved = productDao.addProductDao(product);
//		  inventory.setProductId(product_saved.getProductId());
//		  return product_saved;

		MerchantInventory inventory = new MerchantInventory();
		inventory.setInventoryId(count++);
		// inventory.setProductId(product.getProductId());
		inventory.setProductName(product.getProductName());
		inventory.setProductPrice(product.getProductPrice());
		inventory.setQuantity(product.getProductQuantity());
		inventory.setMerchantId(product.getMerchantId());
		Product product_saved = productDao.addProductDao(product);
		inventory.setProductId(product_saved.getProductId());
		inventoryDao.addItemDao(inventory);
		return product_saved;

		/*
		 * try { return productDao.addProductDao(product); } catch(Exception e) {
		 * e.printStackTrace(); } return product;
		 */

		// }

		// productDao.addProductDao(product);

	}

	@Override
	public Product updateProductService(Product product, int productId) {
		// TODO Auto-generated method stub
		// inventoryDao.updateItemDao(item, itemId)
		MerchantInventory oldItem = inventoryDao.deleteItemByProductIdDao(productId);
		int id = oldItem.getInventoryId();
		inventoryDao.deleteItemDao(id);
		// inventoryDao.deleteItemByProductIdDao(productId);
		MerchantInventory inventory = new MerchantInventory();
		// inventory.setInventoryId();
		inventory.setProductName(product.getProductName());
		inventory.setProductPrice(product.getProductPrice());
		inventory.setQuantity(product.getProductQuantity());
		
		inventory.setMerchantId(product.getMerchantId());
		Product product_updated = productDao.updateProductDao(product, productId);
		inventory.setProductId(product_updated.getProductId());
		
		inventoryDao.addItemDao(inventory);
		return product_updated;
	}

	@Override
	public void deleteProduct(int productId) {

		productDao.deleteProductDao(productId);

	}

	@Override
	public List<MerchantInventory> getAllItemsService() {
		return inventoryDao.getAllItemsDao();
	}

	@Override
	public MerchantInventory getItemService(int itemId) {
		return inventoryDao.getItemDao(itemId);
	}

	public List<MerchantInventory> deleteItem(int productId, int merchantId) {
		// TODO Auto-generated method stub
		MerchantInventory oldItem = inventoryDao.deleteItemByProductIdDao(productId);
		int id = oldItem.getInventoryId();
		inventoryDao.deleteItemDao(id);
		productDao.deleteProductDao(productId);
		System.out.println("hiii");
		System.out.println(inventoryDao.getItemsByMerchantId(merchantId));

		return inventoryDao.getItemsByMerchantId(merchantId);
		

		
	}

	public List<MerchantInventory> getItemByMerchantIdService(int merchantId) {
		// TODO Auto-generated method stub
		return inventoryDao.getItemsByMerchantId(merchantId);
	}

}
