package com.capgemini.capstore.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.capgemini.capstore.beans.Customer;
@Repository
public class CapgCustomerDaoImpl implements ICapgCustomerDao{

	@Autowired
	CustomerDao customerRepo;
	
	@Override
	public Customer addCustomerDao(Customer customer) {
		// TODO Auto-generated method stub
		return customerRepo.save(customer);
		
	}

	@Override
	public List<Customer> getAllCustomerDao() {
		return customerRepo.findAll();
	}

	@Override
	public Customer getCustomerDao(int customerId) {
		// TODO Auto-generated method stub
		return customerRepo.findById(customerId).orElse(null);
	}

	@Override
	public Customer getCustomerByEmailDao(String emailId) {
		// TODO Auto-generated method stub
		System.out.println("hlo");
		return customerRepo.getCustomer(emailId);
	}

}
