package com.capgemini.capstore.beans;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.Email;
import javax.validation.constraints.Pattern;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

@Entity
@Table(name = "capgmerchant")
public class Merchant {
	
	
	/*	create sequence Merchant_sequence
	start with 200;*/
	@Id
	@SequenceGenerator(name="mseq",sequenceName="Merchant_sequence")
    @GeneratedValue(generator="mseq")
	private int merchantId;
	
	@Email
	@Column(unique = true)
	private String merchantEmail;
	
	private String merchantName;
	private String merchantAddress;
	private String merchantMobile;
	private String merchantPassword;
	private String merchantType;
	@Override
	public String toString() {
		return "Merchant [merchantId=" + merchantId + ", merchantEmail=" + merchantEmail + ", merchantName="
				+ merchantName + ", merchantAddress=" + merchantAddress + ", merchantMobile=" + merchantMobile
				+ ", merchantPassword=" + merchantPassword + ", merchantType=" + merchantType + "]";
	}
	public int getMerchantId() {
		return merchantId;
	}
	public void setMerchantId(int merchantId) {
		this.merchantId = merchantId;
	}
	public String getMerchantEmail() {
		return merchantEmail;
	}
	public void setMerchantEmail(String merchantEmail) {
		this.merchantEmail = merchantEmail;
	}
	public String getMerchantName() {
		return merchantName;
	}
	public void setMerchantName(String merchantName) {
		this.merchantName = merchantName;
	}
	public String getMerchantAddress() {
		return merchantAddress;
	}
	public void setMerchantAddress(String merchantAddress) {
		this.merchantAddress = merchantAddress;
	}
	public String getMerchantMobile() {
		return merchantMobile;
	}
	public void setMerchantMobile(String merchantMobile) {
		this.merchantMobile = merchantMobile;
	}
	public String getMerchantPassword() {
		return merchantPassword;
	}
	public void setMerchantPassword(String merchantPassword) {
		this.merchantPassword = merchantPassword;
	}
	public String getMerchantType() {
		return merchantType;
	}
	public void setMerchantType(String merchantType) {
		this.merchantType = merchantType;
	}
	

	
}
