package com.capgemini.capstore.dao;

import java.util.List;

import com.capgemini.capstore.beans.Product;

public interface CapgProductDaoIntf {
	
	public List<Product> getAllProductsDao();

	public Product getProductDao(int productId);

	public Product addProductDao(Product product);

	public Product updateProductDao(Product product,int productId);
	
	public void deleteProductDao(int productId);
}
