package com.capgemini.capstore.controller;

import java.security.NoSuchAlgorithmException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.capstore.beans.Customer;
import com.capgemini.capstore.beans.Merchant;
import com.capgemini.capstore.service.CustomerServiceInterface;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
public class CustomerController {
	
	@Autowired
	CustomerServiceInterface service;
	
	
	
	@GetMapping(value="/allCustomer")
	public List<Customer> allCustomers(){
		//System.out.println(service.allCustomers().toString());
		return service.allCustomers();
	}
	@GetMapping(value="/customer/{customerId}")
	public Customer customerById(@PathVariable int id) {
		System.out.println(id);
		return service.getById(id);
	}
	
	
	
	@PostMapping(value="/create")
	public void addCustomer(@RequestBody Customer customer) throws NoSuchAlgorithmException {
		//customer.setCustomerCartId("101");
		//customer.setCustomerHistory("Empty History");
		customer.setCustomerWallet(2000);
		String encrypted=service.addData(customer);
		customer.setCustomerEncryptedPassword(encrypted);
		//System.out.println(customer);
		service.addCustomer(customer);
	}
	
	
	
	

}
