package com.capgemini.capstore.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.capstore.beans.Product;

@Service
public class DiscountDao implements IDiscountDaoImpl {

	@Autowired
	IDiscountDao productRepo;
	
	
	@Override
	public void setDiscount(int productId, double productDiscount, int delay) {
		Product product = productRepo.findById(productId).orElse(null);
		product.setProductDiscount(productDiscount); 
		productRepo.save(product);
		try {
			Thread.sleep(delay);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		product.setProductDiscount(0); 
		productRepo.save(product);
	}



	@Override
	public void setDiscountByCategory(String productCategory, double productDiscount, int delay) {
		List<Product> product = productRepo.findProductByCategory(productCategory);
		for (Product capgProduct : product) {
			capgProduct.setProductDiscount(productDiscount);
			productRepo.save(capgProduct);
		}
		try {
			Thread.sleep(delay);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		for (Product capgProduct : product) {
			capgProduct.setProductDiscount(0);
			productRepo.save(capgProduct);
		}
		
		
	}


	@Override
	public void setDicountByAmount(double productPrice, double productDiscount, int delay) {
		List<Product> product = productRepo.findProductByAmount(productPrice);
		for (Product capgProduct : product) {
			capgProduct.setProductDiscount(productDiscount);
			productRepo.save(capgProduct);
		}
		try {
			Thread.sleep(delay);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		for (Product capgProduct : product) {
			capgProduct.setProductDiscount(0);
			productRepo.save(capgProduct);
		}
		
	}



}
