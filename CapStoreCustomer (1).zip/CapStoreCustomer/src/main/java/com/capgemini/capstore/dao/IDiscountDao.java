package com.capgemini.capstore.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.capgemini.capstore.beans.Product;

@Repository
public interface IDiscountDao extends JpaRepository<Product, Integer> {

	@Query(value="Select p from capgproduct p where productCategory= :productCategory")
	public List<Product> findProductByCategory(@Param("productCategory") String productCategory);
	
	@Query(value="Select p from capgproduct p where productPrice BETWEEN 0 AND :productPrice")
	public List<Product> findProductByAmount(@Param("productPrice") double productPrice);
	
}
