package com.capgemini.capstore.beans;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;

import org.springframework.stereotype.Component;
@Component
@Entity(name="capgmerchantinventory")
public class MerchantInventory {

	@Id
	@SequenceGenerator(name="seq" , sequenceName = "mer_seq")
	@GeneratedValue(generator = "seq")
	private int inventoryId;
	private int productId;
	private String productName;
	private double productPrice;
	private int quantity;
	private int merchantId;
	
	
	
	public int getMerchantId() {
		return merchantId;
	}
	public void setMerchantId(int merchantId) {
		this.merchantId = merchantId;
	}
	public int getInventoryId() {
		return inventoryId;
	}
	public void setInventoryId(int inventoryId) {
		this.inventoryId = inventoryId;
	}
	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public double getProductPrice() {
		return productPrice;
	}
	public void setProductPrice(double productPrice) {
		this.productPrice = productPrice;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	@Override
	public String toString() {
		return "CapgMerchantInventory [inventoryId=" + inventoryId + ", productId=" + productId + ", productName="
				+ productName + ", productPrice=" + productPrice + ", quantity=" + quantity + "]";
	}
	
	
	
	
	
}
