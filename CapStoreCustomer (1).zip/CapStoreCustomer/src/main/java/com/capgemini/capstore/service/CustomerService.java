package com.capgemini.capstore.service;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.List;

import javax.xml.bind.DatatypeConverter;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.capstore.beans.Customer;
import com.capgemini.capstore.dao.CustomerRepository;

@Service
public class CustomerService implements CustomerServiceInterface {
	
	@Autowired
	CustomerRepository repository;

	@Override
	public void addCustomer(Customer customer) {
		repository.save(customer);
	}

	@Override
	public Customer getById(int customerId) {
		return repository.findById(customerId).orElse(null);
	}

	@Override
	public List<Customer> allCustomers() {
		return repository.findAll();
	}

	
	
	
	///
	@Override
    public String addData(Customer credentials) throws NoSuchAlgorithmException  {

 

        // Create MessageDigest instance for MD5
        MessageDigest messageDigest = MessageDigest.getInstance("MD5");

 

        String password = credentials.getCustomerPassword();
         System.out.println("password enter by you is: "+ password);
        // Add password bytes to digest
        messageDigest.update(password.getBytes());

 

        // Get the hash's bytes
        byte[] digest = messageDigest.digest();

 

        // This bytes[] has bytes in decimal format;
        // Convert it to hexadecimal format and store in String variable
        String myHash = DatatypeConverter.printHexBinary(digest).toUpperCase();
           System.out.println("encryped password is:"+ myHash);
        
        credentials.setCustomerEncryptedPassword(myHash);

 

        // Storing in database
        //credentialsDao.addData(credentials);
        
        return credentials.getCustomerEncryptedPassword();

 

    }
	

	

}
