package com.capgemini.capstore.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.capgemini.capstore.beans.Customer;


@Repository
public interface CustomerDao extends JpaRepository<Customer, Integer> {

	
	@Query("from capgcustomer where customer_email  = :emailId")
	public Customer getCustomer(@Param("emailId") String emailId);
	
	
	/*@Query("select u.password from User u where u.emailid=?1")
	public String getUserPassword(String emailId);*/

}