package com.capgemini.capstore.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.capstore.dao.IDiscountDaoImpl;

@Service
public class DiscountService implements DiscountServiceInterface {

	@Autowired
	IDiscountDaoImpl discountObject;
	
	
	
	
	public void setDiscount(int productId, double productDiscount,int delay) {
		discountObject.setDiscount(productId, productDiscount,delay);
	}





	@Override
	public void setDiscountByCategory(String productCategory, double productDiscount,int delay) {
		
			
			discountObject.setDiscountByCategory(productCategory, productDiscount,delay);
			
		
		
	}





	@Override
	public void setDicountByAmount(double productPrice, double productDiscount,int delay) {
		discountObject.setDicountByAmount(productPrice, productDiscount,delay);
		
	}

}
