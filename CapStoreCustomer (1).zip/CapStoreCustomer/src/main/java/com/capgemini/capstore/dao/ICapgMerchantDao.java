package com.capgemini.capstore.dao;

import java.util.List;

import com.capgemini.capstore.beans.Merchant;

public interface ICapgMerchantDao {

	public Merchant addMerchantDao(Merchant merchant);
	
	public List<Merchant> getAllMerchantDao();
	
	public Merchant getMerchantDao(int merchantId);
	
	public Merchant getMerchantByEmailDao(String emailId);

	
}
