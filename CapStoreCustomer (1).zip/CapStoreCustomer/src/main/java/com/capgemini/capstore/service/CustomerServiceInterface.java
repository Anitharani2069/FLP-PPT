package com.capgemini.capstore.service;

import java.security.NoSuchAlgorithmException;
import java.util.List;

import com.capgemini.capstore.beans.Customer;

public interface CustomerServiceInterface {
	
	public void addCustomer(Customer customer);
	
	public Customer getById(int customerId);
	
	public List<Customer> allCustomers();
	
	
	public String addData(Customer credentials) throws NoSuchAlgorithmException ;
	

}
