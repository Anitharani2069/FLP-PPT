package com.capgemini.capstore.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.capgemini.capstore.beans.Customer;
import com.capgemini.capstore.beans.Merchant;
import com.capgemini.capstore.beans.Product;


public interface AdminServiceInterface {
	
	List<Customer> findAllCustomers();
	
	List<Product> findAllProducts();
	
	List<Merchant> findAllMerchants();
	
	public void deleteCustomer(int customerId);
	public void deleteProduct(int productId);
	public void deleteMerchant(int merchantId);

}
