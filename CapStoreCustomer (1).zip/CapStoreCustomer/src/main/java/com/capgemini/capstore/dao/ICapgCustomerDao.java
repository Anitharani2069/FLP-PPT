package com.capgemini.capstore.dao;

import java.util.List;

import com.capgemini.capstore.beans.Customer;

public interface ICapgCustomerDao {
	
	
	public Customer addCustomerDao(Customer customer);
	
	public List<Customer> getAllCustomerDao();
	
	public Customer getCustomerDao(int customerId);
	
	public Customer getCustomerByEmailDao(String emailId);

	
	


}
