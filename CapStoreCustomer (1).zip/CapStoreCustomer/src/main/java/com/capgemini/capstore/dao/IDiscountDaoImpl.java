package com.capgemini.capstore.dao;

public interface IDiscountDaoImpl {

	public void setDiscount(int productId,double productDiscount, int delay);
	
	public void setDiscountByCategory(String productCategory,double productDiscount,int delay);
	
	public void setDicountByAmount(double productPrice,double productDiscount,int delay);
}
