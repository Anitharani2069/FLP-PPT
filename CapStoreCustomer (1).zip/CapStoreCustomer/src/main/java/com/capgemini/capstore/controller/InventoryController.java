package com.capgemini.capstore.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.capstore.beans.MerchantInventory;
import com.capgemini.capstore.beans.Product;
import com.capgemini.capstore.service.CapgProductServiceImpl;

@RestController
@CrossOrigin(origins = "http://localhost:4200")

public class InventoryController {

	@Autowired
	CapgProductServiceImpl productService;

	@GetMapping("/product/getAllProduct")
	public List<Product> getAllProduct() {
		System.out.println(productService.getAllProductsService().toString());
		return productService.getAllProductsService();
	}

	@GetMapping("/product/getProduct/{productId}")
	public Product getProduct(@PathVariable int productId) {
		return productService.getProductService(productId);
	}

	@PostMapping("/product/addProduct")
	public void addProduct(@RequestBody Product product) {
		System.out.println(product);
		productService.addProductService(product);
	}

	@PutMapping("/product/updateProduct/{productId}")
	public Product updateProduct(@RequestBody Product product, @PathVariable int productId) {
		return productService.updateProductService(product, productId);
	}

	@DeleteMapping("/product/removeItem/{productId}/{merchantId}")
	public List<MerchantInventory> deleteProduct(@PathVariable int productId,@PathVariable int merchantId) {
		
		return productService.deleteItem(productId,merchantId);
		
		
	}

	@GetMapping("/item/getAllItem")
	public List<MerchantInventory> getAllItem() {
		System.out.println(productService.getAllItemsService().toString());
		return productService.getAllItemsService();
	}

	@GetMapping("/product/getItem/{itemId}")
	public MerchantInventory getItem(@PathVariable int itemId) {
		return productService.getItemService(itemId);
	}
	
	@GetMapping("/item/getItemByMerchantId/{productId}")
	public List<MerchantInventory> getItems(@PathVariable int productId){
		return productService.getItemByMerchantIdService(productId);
	}

}
