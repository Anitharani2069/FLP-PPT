package com.capgemini.capstore.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.capgemini.capstore.beans.Merchant;
@Repository
public class CapgMerchantDaoImpl implements ICapgMerchantDao{
	
	
	@Autowired
	MerchantDao merchantRepo;

	@Override
	public Merchant addMerchantDao(Merchant merchant) {
		return merchantRepo.save(merchant);
		
	}

	@Override
	public List<Merchant> getAllMerchantDao() {
		return merchantRepo.findAll();
	}

	@Override
	public Merchant getMerchantDao(int merchantId) {
		// TODO Auto-generated method stub
		return merchantRepo.findById(merchantId).orElse(null);
	}

	@Override
	public Merchant getMerchantByEmailDao(String emailId) {
		// TODO Auto-generated method stub
		return merchantRepo.getMerchant(emailId);
	}

}
