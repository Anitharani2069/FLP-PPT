package com.capgemini.capstore.dao;

import java.util.List;

import com.capgemini.capstore.beans.MerchantInventory;

public interface ICapgMerchantInventoryDao {
	
	public List<MerchantInventory> getAllItemsDao();

	public MerchantInventory getItemDao(int itemId);

	public MerchantInventory addItemDao(MerchantInventory item);

	public MerchantInventory updateItemDao(MerchantInventory item,int itemId);
	
	public void deleteItemDao(int itemId);

}
