package com.capgemini.capstore.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.capstore.beans.Customer;
import com.capgemini.capstore.beans.Merchant;
import com.capgemini.capstore.service.PasswordService;



@CrossOrigin(origins = "http://localhost:4200")
@RestController
//@RequestMapping("/forgot")
public class PasswordController {

	@Autowired
	private PasswordService service;
	
	
	/*private String secretKey="SomeSecretKey";
	@PostMapping(value = "/getPass", consumes = { "application/json" })
	public PasswordEmail getPassword(@RequestBody PasswordFormat input) {

		String password = service.getPassword(input.getEmail(), input.getCategory(), input.getAnswer1(),input.getAnswer2());
		
		if(password!=null)
		{
		PasswordEmail pe=new PasswordEmail();
		Cryptography c=new Cryptography();
		String decryptedPassword=c.decrypt(password,this.secretKey);
		pe.setEmailid(input.getEmail());
		pe.setPassword(decryptedPassword);
		return pe;
		}
		else
		{
			throw new ApplicationException("Email ID not exist or answers are wrong");
		}
		
	}*/
	
	
	@GetMapping("/forgetPassword/{emailId}/{type}")
	public String getPassword(@PathVariable("emailId") String emailId,@PathVariable("type") String type) {
		System.out.println(type);
		System.out.println(emailId);
		System.out.println(service.getPasswordService(emailId,type));
		return service.getPasswordService(emailId,type);
	}
//	@PostMapping("/addAdmin")
//	public CapgAdmin addAdmin(@RequestBody CapgAdmin admin) {
//		return service.addAdminService(admin);
//	}
	
	@PostMapping("/addCustomer")
	public Customer addCustomer(@RequestBody Customer customer) {
		return service.addCustomerService(customer);
	}
	
	@PostMapping("/addMerchant")
	public Merchant addMerchant(@RequestBody Merchant merchant) {
		return service.addMerchantService(merchant);
	}
	
	
	
	
	
	
}
