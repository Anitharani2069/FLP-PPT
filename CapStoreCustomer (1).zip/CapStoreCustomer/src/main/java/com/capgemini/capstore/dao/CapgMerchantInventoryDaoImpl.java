package com.capgemini.capstore.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.capgemini.capstore.beans.MerchantInventory;
@Repository
public class CapgMerchantInventoryDaoImpl implements ICapgMerchantInventoryDao{

	@Autowired
	CapgMerchantInventoryRepository inventoryRepo;

	@Override
	public List<MerchantInventory> getAllItemsDao() {
		return inventoryRepo.findAll();
	}

	@Override
	public MerchantInventory getItemDao(int itemId) {
		return inventoryRepo.findById(itemId).orElse(null);
	}

	@Override
	public MerchantInventory addItemDao(MerchantInventory item) {
		return inventoryRepo.save(item);
	}

	@Override
	public MerchantInventory updateItemDao(MerchantInventory item, int itemId) {
		return inventoryRepo.save(item);
	}

	@Override
	public void deleteItemDao(int itemId) {
		inventoryRepo.deleteById(itemId);
		
	}

	public MerchantInventory deleteItemByProductIdDao(int productId) {
		// TODO Auto-generated method stub
		return inventoryRepo.getItemByProductId(productId);
		
	}

	public List<MerchantInventory> getItemsByMerchantId(int merchantId) {
		return inventoryRepo.getItemsByMerchantId(merchantId);
	}
	
	
}
