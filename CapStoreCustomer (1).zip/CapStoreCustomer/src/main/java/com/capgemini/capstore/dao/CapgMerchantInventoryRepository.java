package com.capgemini.capstore.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.capgemini.capstore.beans.MerchantInventory;


@Repository
public interface CapgMerchantInventoryRepository extends JpaRepository<MerchantInventory, Integer>{
	
	@Query("from capgmerchantinventory where product_id = :productID")
	public MerchantInventory getItemByProductId(@Param("productID") int productID);

	@Query("from capgmerchantinventory where merchant_Id = :merchantId" )
	public List<MerchantInventory> getItemsByMerchantId(@Param("merchantId") int merchantId);

}
