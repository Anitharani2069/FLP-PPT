package com.capgemini.capstore.service;

import java.util.List;

import com.capgemini.capstore.beans.Customer;
import com.capgemini.capstore.beans.Merchant;

public interface PasswordService {

	//public String getPassword(String email, String category,String ans1,String ans2);
	//public CapgAdmin addAdminService(CapgAdmin admin);
	
	public Customer addCustomerService(Customer customer);
	
	public Merchant addMerchantService(Merchant merchant);
	
	//public List<CapgAdmin> getAllAdminService();
	
	//public CapgAdmin getAdminService(int adminId);
	
	public void addCustomerDao(Customer customer);
	
	public List<Customer> getAllCustomerDao();
	
	public Customer getCustomerDao(int customerId);
	
	public void addMerchantDao(Merchant merchant);
	
	public List<Merchant> getAllMerchantDao();
	
	public Merchant getMerchantDao(int merchantId);

	public String getPasswordService(String emailId, String type);
	
	
	
}