package com.capgemini.capstore.service;

public interface DiscountServiceInterface {
	
public void setDiscount(int productId, double productDiscount,int delay);
	
	public void setDicountByAmount(double productPrice,double productDiscount,int delay);

	public void setDiscountByCategory(String productCategory, double productDiscount,int delay);

}
