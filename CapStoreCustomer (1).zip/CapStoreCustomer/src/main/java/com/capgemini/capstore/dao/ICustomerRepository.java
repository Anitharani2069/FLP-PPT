package com.capgemini.capstore.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.capgemini.capstore.beans.Customer;


@Repository
public interface ICustomerRepository extends JpaRepository<Customer, Integer> {
	
//	@Query("delete from customer where customer_id=:custId")
//	public void deleteCustomerById(@Param("custId") int custId);


}
